package com.elmorshdi.trainingtask

data class Product(
    var id: Int?,
    var image: String?,
    var name: String?,
    var price: Int?,
    var quantity: Int?,
    var restaurant_id: Int?
)